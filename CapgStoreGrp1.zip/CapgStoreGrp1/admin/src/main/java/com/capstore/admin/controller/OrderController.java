package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.OrderDTO;

import com.capstore.admin.repository.OrderRepository;


@RestController
@RequestMapping("api/v1/")
public class OrderController {

	
	@Autowired
	private OrderRepository orderRepository;

	@RequestMapping(value = "users/findAllOrders", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<OrderDTO> list() {
		return orderRepository.findAll();
	}

	@RequestMapping(value = "users/addOrder", method = RequestMethod.POST)
	public OrderDTO create(@RequestBody OrderDTO orderDTO) {
		return orderRepository.saveAndFlush(orderDTO);
	}

	@RequestMapping(value = "users/findOrderById/{id}", method = RequestMethod.GET)
	public OrderDTO get(@PathVariable Integer id) {
		return orderRepository.findOne(id);
	}
	
	@RequestMapping(value = "users/DeleteOrderById/{id}", method = RequestMethod.DELETE)
	public OrderDTO delete(@PathVariable Integer id) {
		OrderDTO existingMerchant = orderRepository.findOne(id);
		orderRepository.delete(existingMerchant);
		return existingMerchant;
	
}
}

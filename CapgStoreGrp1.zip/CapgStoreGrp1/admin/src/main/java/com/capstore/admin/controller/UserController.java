package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.CustomerDTO;
import com.capstore.admin.model.UserDTO;
import com.capstore.admin.repository.UserRepository;


@RestController
@RequestMapping("api/v1/")
public class UserController {
//Apna vaala
	@Autowired
	private UserRepository userRepository;

	@RequestMapping(value = "login/users", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<UserDTO> list() {
		return userRepository.findAll();
	}

	@RequestMapping(value = "loginPage/adduser", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO create(@RequestBody UserDTO customerDTO) {
		return userRepository.saveAndFlush(customerDTO);
	}

	@RequestMapping(value = "loginPage/findUserById/{email}", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO get(@PathVariable String email) {
		return userRepository.findOne(email);
	}

	@RequestMapping(value = "loginPage/UpdateUserById/{email}", method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO update(@PathVariable String email, @RequestBody CustomerDTO customerDTO) {
		UserDTO existingUser = userRepository.findOne(email);
		BeanUtils.copyProperties(customerDTO, existingUser);
		return userRepository.saveAndFlush(existingUser);
	}

	@RequestMapping(value = "loginPage/DeleteUserById/{email}", method = RequestMethod.DELETE,consumes = MediaType.APPLICATION_JSON_VALUE)
	public UserDTO delete(@PathVariable String email) {
		UserDTO existingUser = userRepository.findOne(email);
		userRepository.delete(existingUser);
		return existingUser;
	}
	
	
	
}

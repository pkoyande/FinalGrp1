package com.capstore.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.admin.model.ProductDTO;
import com.capstore.admin.repository.ProductRepository;
@RestController
@RequestMapping("api/v1/")
public class ProductController 
{
	@Autowired
	private ProductRepository productRepository;

	@RequestMapping(value = "adminPage/findAllProduct", method = RequestMethod.GET,consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> list() {
		return productRepository.findAll();
	}

	@RequestMapping(value = "adminPage/addProduct", method = RequestMethod.POST)
	public ProductDTO create(@RequestBody ProductDTO productDTO) {
		return productRepository.saveAndFlush(productDTO);
	}

	@RequestMapping(value = "adminPage/findProductById/{id}", method = RequestMethod.GET)
	public ProductDTO get(@PathVariable Integer id) {
		return productRepository.findOne(id);
	}
	
	@RequestMapping(value = "adminPage/DeleteProductById/{id}", method = RequestMethod.DELETE)
	public ProductDTO delete(@PathVariable Integer id) {
		ProductDTO existingMerchant = productRepository.findOne(id);
		productRepository.delete(existingMerchant);
		return existingMerchant;
	}


}

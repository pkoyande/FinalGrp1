package com.capstore.admin.model;

import java.io.Serializable;

import javax.persistence.Column;

public class WishlistKey implements Serializable{

	@Column(name="customerid") 
	private int customerid;
	@Column(name="productid") 
	private int productid;
	@Column(name="productprice") 
	private int productprice;
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public int getProductprice() {
		return productprice;
	}
	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}
	
	
}

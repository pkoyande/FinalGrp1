
package com.capstore.admin.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "productdetail")
public class ProductDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "productid")
	private int productId;

	@Column(name = "merchantid")
	private int merchantid;



	@Column(name = "productname")
	private String productName;
	@Column(name = "productprice")
	private int productPrice;
	@Column(name = "productquantity")
	private int productQuantity;
	private int discountoffered;
	private String productcategory;
	private String producttype;
	private String productbrand;
	private String productmodel;
	private String productfeatures;
	private double productrating;
	private String productfeedback;
	
	public ProductDTO(){
		
	}

	
	
	public ProductDTO(int productId, int merchantid, String productName, int productPrice, int productQuantity,
			int discountoffered, String productcategory, String producttype, String productbrand, String productmodel,
			String productfeatures, double productrating, String productfeedback) {
		super();
		this.productId = productId;
		this.merchantid = merchantid;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productQuantity = productQuantity;
		this.discountoffered = discountoffered;
		this.productcategory = productcategory;
		this.producttype = producttype;
		this.productbrand = productbrand;
		this.productmodel = productmodel;
		this.productfeatures = productfeatures;
		this.productrating = productrating;
		this.productfeedback = productfeedback;
	}



	@ManyToOne(targetEntity = CartDTO.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "productid", insertable = false, updatable = false)
	@JsonBackReference("cartproduct")
	private CartDTO carts;

	@ManyToMany(mappedBy = "products")
	// @JoinColumn(name="productid", insertable=false, updatable=false)
	private List<MerchantDTO> merchants;

	public int getProductId() {
		return productId;
	}
	
	public int getMerchantid() {
		return merchantid;
	}

	public void setMerchantid(int merchantid) {
		this.merchantid = merchantid;
	}
	

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}

	public int getDiscountOffered() {
		return discountoffered;
	}

	public void setDiscountOffered(int discountOffered) {
		this.discountoffered = discountOffered;
	}

	public String getProductCategory() {
		return productcategory;
	}

	public void setProductCategory(String productCategory) {
		this.productcategory = productCategory;
	}

	public String getProductType() {
		return producttype;
	}

	public void setProductType(String productType) {
		this.producttype = productType;
	}

	public String getProductBrand() {
		return productbrand;
	}

	public void setProductBrand(String productBrand) {
		this.productbrand = productBrand;
	}

	public String getProductModel() {
		return productmodel;
	}

	public void setProductModel(String productModel) {
		this.productmodel = productModel;
	}

	public String getProductFeatures() {
		return productfeatures;
	}

	public void setProductFeatures(String productFeatures) {
		this.productfeatures = productFeatures;
	}

	public double getProductRating() {
		return productrating;
	}

	public void setProductRating(double productRating) {
		this.productrating = productRating;
	}

	public String getProductFeedback() {
		return productfeedback;
	}

	public void setProductFeedback(String productFeedback) {
		this.productfeedback = productFeedback;
	}

	/*public List<MerchantDTO> getMerchants() {
		return merchants;
	}

	public void setMerchants(List<MerchantDTO> merchantDTO) {
		this.merchants = merchantDTO;
	}
*/
}
